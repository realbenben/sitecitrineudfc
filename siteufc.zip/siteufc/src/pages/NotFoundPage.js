const NotFoundPage = () => {
  return <div>404 U reached the flat net border broooh!</div>;
};

export default NotFoundPage;
