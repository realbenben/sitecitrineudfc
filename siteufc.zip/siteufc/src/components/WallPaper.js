import React from 'react';

const WallPaper = () => {
    return (
        // <div className="main">
        <div className="wall">
            <div className="bg-img">
                
            </div>
        </div>
        // </div>
    );
};

export default WallPaper;