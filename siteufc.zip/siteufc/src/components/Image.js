import React from "react";
import FighterData from "../team.json";
export default function Image() {
  return <div></div>;
}
